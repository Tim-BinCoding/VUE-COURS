<template>
    <friend-menu></friend-menu>
    <friend-form></friend-form>
    <friend-card></friend-card>
</template>

<script>
import FriendCard from './components/FriendCard.vue';
export default {
  components: { FriendCard },
  data() {
    return {};
  },
};
</script>

<style>

</style>
